
# NutriFarms — Static Multi-page Starter Site

This is a frontend-only static site for NutriFarms. It uses placeholder images and static QR previews.
You can upload this repo to GitHub and deploy via GitHub Pages or Vercel.

## Run locally (quick)
1. Unzip the project.
2. Open `index.html` in your browser — or run a simple static server:
   - Python 3: `python -m http.server 8000`
   - Then open http://localhost:8000

## Deploy to GitHub Pages
1. Create a new GitHub repository.
2. Add the project files and commit & push.
3. On GitHub, go to **Settings → Pages**.
4. Under "Source" select the branch (usually `main`) and `/ (root)` folder, then Save.
5. Your site will be published at `https://<username>.github.io/<repo>/` in a few minutes.

## Deploy to Vercel (recommended for static sites)
1. Sign in to https://vercel.com and click "New Project".
2. Import your GitHub repo.
3. Set Framework Preset to "Other" or "Static".
4. Click "Deploy". It will publish on a vercel.app domain automatically.

## Notes
- Replace placeholder images and FSSAI/IEC values before production.
- For dynamic QR & lab reports, you'll need a backend or a headless CMS to host PDFs and generate links.
