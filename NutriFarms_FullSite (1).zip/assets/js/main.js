
document.addEventListener('click', (e)=>{
  if(e.target.matches('.buy-btn')){
    alert('Add to cart (placeholder)');
  }
  if(e.target.matches('.qr-btn')){
    alert('QR Preview (static placeholder)');
  }
});
