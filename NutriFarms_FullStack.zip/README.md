
# NutriFarms — Fullstack (Static frontend + simple Express backend)

This project contains a static multi-page frontend (in /public) and a small Node/Express server (server.js) that serves the site and provides a mock /api/qr/:batch endpoint for QR/batch previews.

## Run locally
1. Install Node (v16+ recommended).
2. In the project root, install dependencies:
   npm install
3. Start the server:
   npm start
4. Open http://localhost:3000

## Deploy to Heroku (quick)
1. Create a new Heroku app and connect your GitHub repo, or use Heroku CLI:
   heroku create <app-name>
2. Push code to Heroku (git push heroku main)
Heroku will run `npm start` and host the server (serves frontend + API).

## Deploy to Vercel (recommended for static + serverless)
- You can deploy the /public folder as a static site on Vercel (or GitHub Pages) and implement the /api/qr as a serverless function if you want. For simple hosting, deploy the whole repo to Heroku or Render as a Node app.

## Note
- The /api/qr endpoint returns mock data — replace with real lab data source for production.
- Replace placeholder images, FSSAI/IEC numbers, and contact details.
