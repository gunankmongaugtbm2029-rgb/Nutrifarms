
document.addEventListener('click', (e)=>{
  if(e.target.matches('.buy-btn')){
    alert('Add to cart (placeholder)');
  }
  if(e.target.matches('.qr-btn')){
    const batch = e.target.dataset.batch || '4092';
    fetch('/api/qr/' + batch).then(r=>r.json()).then(data=>{
      const html = `Batch: ${data.batch}\nLab: ${data.lab}\nPollen: ${data.metrics.pollen}\nMoisture: ${data.metrics.moisture}`;
      alert(html);
    }).catch(()=>alert('Could not fetch QR preview.'));
  }
});
